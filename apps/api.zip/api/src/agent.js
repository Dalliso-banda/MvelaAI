import crypto from 'node:crypto';
import { db, now, audit } from './db.js';
import { runTool } from './tools.js';
import { redact, riskCheck, detectIntent, detectLanguage, extractPhone, extractOtp, TOPIC_BY_INTENT, scrubOutput } from './guardrails.js';
import { llmEnabled, llmProvider, runLLM } from './llm.js';

const BUSINESS = () => process.env.BUSINESS_NAME || 'Demo Bank Zambia';
const OTP_TTL_MS = 5 * 60 * 1000;
const MAX_OTP_ATTEMPTS = 3;
const MAX_PHONE_SUBMISSIONS = 5;

const getConv = (id) => db.prepare('SELECT * FROM conversations WHERE id=?').get(id);
const sha = (code, convId) => crypto.createHash('sha256').update(`${convId}:${code}`).digest('hex');
const maskPhone = (p) => `${p.slice(0, 4)} *** ***${p.slice(-3)}`;
const first = (n) => String(n).split(' ')[0];
const patch = (id, fields) => {
  const keys = Object.keys(fields);
  db.prepare(`UPDATE conversations SET ${keys.map((k) => `${k}=?`).join(',')}, updated_at=? WHERE id=?`).run(...keys.map((k) => fields[k]), now(), id);
};
const addMessage = (conversationId, role, kind, content, latency = null) =>
  db.prepare('INSERT INTO messages (conversation_id, role, kind, content, latency_ms, created_at) VALUES (?,?,?,?,?,?)').run(conversationId, role, kind, content, latency, now());

export function createConversation({ channel = 'web' } = {}) {
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO conversations (id, channel, created_at, updated_at) VALUES (?,?,?,?)').run(id, channel, now(), now());
  const greeting = `Hello, I'm Mvela, ${BUSINESS()}'s virtual assistant. I can help with balances, recent transactions, failed or pending transfers and general questions, in English, Bemba or Nyanja. How can I help?`;
  addMessage(id, 'assistant', 'flow', greeting);
  audit(id, null, 'system', 'conversation_started', { channel });
  return { id, greeting };
}

// ---------------------------------------------------------------- OTP
function deliverOtp(phone, code) {
  // TODO(prod): send via an SMS provider (e.g. Africa's Talking / Twilio). Never log codes in production.
  if (process.env.OTP_DEMO !== 'false') return { demoOtp: code };
  return {};
}

function startOtp(conv, phone) {
  const submissions = db.prepare("SELECT COUNT(*) c FROM audit_logs WHERE conversation_id=? AND action LIKE 'otp_requested%'").get(conv.id).c;
  if (submissions >= MAX_PHONE_SUBMISSIONS) {
    audit(conv.id, null, 'system', 'otp_rate_limited');
    return { text: 'Too many verification attempts on this chat. For your security I can\'t continue. Please start a new chat later, or ask for a human agent.', kind: 'flow' };
  }
  const customer = db.prepare('SELECT * FROM customers WHERE phone=?').get(phone);
  let extra = {};
  if (customer) {
    const code = String(crypto.randomInt(100000, 1000000));
    db.prepare('UPDATE otps SET used=1 WHERE conversation_id=? AND used=0').run(conv.id);
    db.prepare('INSERT INTO otps (conversation_id, customer_id, code_hash, expires_at, created_at) VALUES (?,?,?,?,?)')
      .run(conv.id, customer.id, sha(code, conv.id), new Date(Date.now() + OTP_TTL_MS).toISOString(), now());
    extra = deliverOtp(phone, code);
    audit(conv.id, customer.id, 'system', 'otp_requested', { phone: maskPhone(phone) });
  } else {
    // Same response either way so the chat can't be used to discover which numbers are customers.
    audit(conv.id, null, 'system', 'otp_requested_unknown', { phone: maskPhone(phone) });
  }
  patch(conv.id, { state: 'awaiting_otp', pending_phone: phone });
  const demo = extra.demoOtp ? `\n\nDemo mode: no SMS is sent, so your code is ${extra.demoOtp}.` : '';
  return { text: `If ${maskPhone(phone)} is registered with us, I've sent a 6-digit code to it. Please type the code here. It expires in 5 minutes. (Never share your PIN or password with anyone.)${demo}`, kind: 'flow', ...extra };
}

async function verifyOtp(conv, code) {
  const row = db.prepare('SELECT * FROM otps WHERE conversation_id=? AND used=0 ORDER BY id DESC LIMIT 1').get(conv.id);
  if (!row || new Date(row.expires_at) < new Date() || row.attempts >= MAX_OTP_ATTEMPTS) {
    if (row) db.prepare('UPDATE otps SET used=1 WHERE id=?').run(row.id);
    patch(conv.id, { state: 'awaiting_phone' });
    audit(conv.id, null, 'system', 'otp_failed', { reason: row ? 'expired_or_locked' : 'none_issued' });
    return { text: 'That code is no longer valid. Please type your registered mobile number again and I\'ll send a new one.', kind: 'flow' };
  }
  const ok = crypto.timingSafeEqual(Buffer.from(sha(code, conv.id)), Buffer.from(row.code_hash));
  if (!ok) {
    db.prepare('UPDATE otps SET attempts=attempts+1 WHERE id=?').run(row.id);
    const left = MAX_OTP_ATTEMPTS - row.attempts - 1;
    audit(conv.id, row.customer_id, 'system', 'otp_failed', { reason: 'wrong_code', attempts_left: left });
    if (left <= 0) patch(conv.id, { state: 'awaiting_phone' });
    return { text: left > 0 ? `That code isn't right. You have ${left} ${left === 1 ? 'try' : 'tries'} left.` : "That code isn't right and you're out of tries. Please type your mobile number again for a new code.", kind: 'flow' };
  }
  db.prepare('UPDATE otps SET used=1 WHERE id=?').run(row.id);
  patch(conv.id, { state: 'verified', customer_id: row.customer_id, pending_phone: null });
  audit(conv.id, row.customer_id, 'system', 'verified');
  const customer = db.prepare('SELECT name FROM customers WHERE id=?').get(row.customer_id);
  return { text: `Thank you ${first(customer.name)}, you're verified.`, kind: 'flow', justVerified: true };
}

// ---------------------------------------------------------------- escalation
const RISK_REPLY = {
  fraud: "I'm sorry this has happened. I've marked this as urgent and passed it to a human agent with the details of this chat. In the meantime, don't share your PIN, password or any one-time code with anyone, including us.",
  complaint: "I'm sorry about your experience. I've passed this to a human agent with the full chat so you won't need to repeat yourself.",
  human: "Of course. I've passed this chat to a human agent with everything so far, so you won't need to repeat yourself.",
  card_action: "For your security I can't block, unblock or replace cards myself. I've sent this to a human agent as a priority and they'll verify you and take care of it.",
  out_of_scope: "I can't move money or change account details; I'm read-only for your safety. I've passed this to a human agent who can help.",
};
function escalateFor(conv, risk) {
  runTool('escalate_to_human', { reason: `${risk.type.replace('_', ' ')} (auto-detected)`, priority: risk.priority }, ctxOf(conv));
  return { text: RISK_REPLY[risk.type], kind: 'chat', topic: TOPIC_BY_INTENT[risk.type], escalated: true };
}
const ctxOf = (conv) => ({ conversationId: conv.id, customerId: conv.customer_id, used: [] });

// ---------------------------------------------------------------- rules engine (no LLM)
const lines = (arr) => arr.join('\n');
const txLine = (t) => `• ${t.reference}: ${t.direction === 'debit' ? '-' : '+'}${t.amount} ${t.counterparty ? (t.direction === 'debit' ? 'to ' : 'from ') + t.counterparty : t.type} via ${t.channel}, ${t.status.toUpperCase()}, ${t.date.slice(0, 10)}`;

function rulesAnswer(conv, text) {
  const ctx = ctxOf(conv);
  const name = first(db.prepare('SELECT name FROM customers WHERE id=?').get(conv.customer_id).name);
  const intent = detectIntent(text);
  const topic = TOPIC_BY_INTENT[intent];
  const kb = () => runTool('search_knowledge', { query: text }, ctx).results;

  if (intent === 'greeting') return { text: `Hello ${name}. What would you like help with?`, topic, answered: false };
  if (intent === 'thanks') return { text: 'You\'re welcome. Anything else I can help with?', topic, answered: false };
  if (intent === 'balance') {
    const { accounts } = runTool('get_account_summary', {}, ctx);
    return { text: lines(['Here are your balances:', ...accounts.map((a) => `• ${a.type} ${a.account}: ${a.balance}${a.status !== 'active' ? ` (${a.status})` : ''}`)]), topic, answered: true };
  }
  if (intent === 'transactions') {
    const { transactions } = runTool('get_recent_transactions', { limit: 5 }, ctx);
    return { text: transactions.length ? lines(['Your latest transactions:', ...transactions.map(txLine)]) : 'I couldn\'t find any recent transactions.', topic, answered: true };
  }
  if (intent === 'transaction_status') {
    const ref = (text.match(/TXN-\d+/i) || [])[0];
    const wanted = /fail|didn'?t (go|arrive|receive|reach)|not (received|delivered|arrive|reach)/i.test(text) ? 'failed' : /pending|stuck/i.test(text) ? 'pending' : /revers|refund/i.test(text) ? 'reversed' : undefined;
    const r = runTool('get_transaction_status', ref ? { reference: ref } : { status: wanted }, ctx);
    if (!r.found) return { text: `${r.note} If you give me the reference number (it looks like TXN-100234) I can look it up directly.`, topic, answered: true };
    const t = r.transaction;
    return { text: lines([`${t.reference}: ${t.amount} ${t.direction === 'debit' ? 'to' : 'from'} ${t.counterparty ?? t.type} via ${t.channel} on ${t.date.slice(0, 10)} is ${t.status.toUpperCase()}.`,
      t.failure_reason ? `Reason: ${t.failure_reason}.` : '', t.next_step ? `Next step: ${t.next_step}` : '']).replace(/\n+$/g, '').replace(/\n{2,}/g, '\n'), topic, answered: true };
  }
  if (intent === 'card_status') {
    const { cards } = runTool('get_card_status', {}, ctx);
    return { text: cards.length ? lines(['Your cards:', ...cards.map((c) => `• ${c.card}: ${c.status}, expires ${c.expires}`)]) : 'There are no cards on your profile.', topic, answered: true };
  }
  const hits = kb();
  if (hits.length && hits[0].score >= 3) return { text: `${hits[0].answer}`, topic: 'General enquiry', answered: true };
  runTool('escalate_to_human', { reason: 'AI could not answer: ' + text.slice(0, 120), priority: 'low' }, ctx);
  return { text: "I couldn't find a reliable answer to that, so I've passed it to a human agent rather than guess. They'll pick it up from this chat.", topic: 'General enquiry', escalated: true };
}

async function verifiedAnswer(conv, text) {
  if (llmEnabled()) {
    const ctx = ctxOf(conv);
    try {
      const customer = db.prepare('SELECT name FROM customers WHERE id=?').get(conv.customer_id);
      const history = db.prepare("SELECT role, content FROM messages WHERE conversation_id=? AND kind='chat' ORDER BY id DESC LIMIT 12").all(conv.id).reverse();
      const out = await runLLM({ history, ctx, name: customer.name, language: conv.language, business: BUSINESS() });
      const intent = detectIntent(text);
      const escalated = ctx.used.includes('escalate_to_human');
      audit(conv.id, conv.customer_id, 'ai', 'reply', { mode: llmProvider(), tools: ctx.used });
      return { text: out, topic: TOPIC_BY_INTENT[intent], answered: !escalated, escalated };
    } catch (e) {
      audit(conv.id, conv.customer_id, 'system', 'llm_error_fallback', { error: String(e.message).slice(0, 200) });
      console.warn('[llm] FELL BACK to the rules agent:', e.message);
    }
  }
  const r = rulesAnswer(conv, text);
  audit(conv.id, conv.customer_id, 'ai', 'reply', { mode: 'rules' });
  return r;
}

// Before verification the model gets no account tools, only the public knowledge base and escalation.
async function publicAnswer(conv) {
  if (!llmEnabled()) return null;
  const ctx = { conversationId: conv.id, customerId: null, used: [] };
  try {
    const history = db.prepare("SELECT role, content FROM messages WHERE conversation_id=? AND kind='chat' ORDER BY id DESC LIMIT 12").all(conv.id).reverse();
    const text = await runLLM({ history, ctx, name: 'a visitor', language: conv.language, business: BUSINESS(), publicMode: true });
    audit(conv.id, null, 'ai', 'reply', { mode: llmProvider(), public: true, tools: ctx.used });
    return { text, escalated: ctx.used.includes('escalate_to_human') };
  } catch (e) {
    audit(conv.id, null, 'system', 'llm_error_fallback', { error: String(e.message).slice(0, 200), public: true });
    console.warn('[llm] FELL BACK to the scripted reply (public mode):', e.message);
    return null;
  }
}

// ---------------------------------------------------------------- main entry
export async function handleMessage(conversationId, rawText) {
  let conv = getConv(conversationId);
  if (!conv) throw Object.assign(new Error('Conversation not found'), { status: 404 });
  const t0 = performance.now();
  const text = String(rawText || '').trim().slice(0, 1000);
  const risk = riskCheck(text);
  const lang = detectLanguage(text);
  if (lang !== 'English' && lang !== conv.language) { patch(conv.id, { language: lang }); conv = getConv(conv.id); }

  const otpMode = conv.state === 'awaiting_otp';
  const code = otpMode ? extractOtp(text) : null;
  const { text: safe, sensitive } = redact(text);
  const storedText = code ? '[verification code entered]' : safe;

  let reply;
  let customerKind = 'flow';

  if (risk && !(otpMode && code)) {
    customerKind = 'chat';
    // store first so the escalation summary includes this message
    addMessage(conv.id, 'customer', customerKind, storedText);
    reply = escalateFor(conv, risk);
  } else if (conv.state === 'verified') {
    customerKind = 'chat';
    addMessage(conv.id, 'customer', customerKind, storedText);
    reply = await verifiedAnswer(conv, safe);
  } else {
    // unverified: new | awaiting_phone | awaiting_otp
    const phone = extractPhone(text);
    if (code) {
      addMessage(conv.id, 'customer', 'flow', storedText);
      reply = await verifyOtp(conv, code);
    } else if (phone) {
      addMessage(conv.id, 'customer', 'flow', storedText);
      reply = startOtp(conv, phone);
    } else if (otpMode && /resend|again|new code/i.test(text) && conv.pending_phone) {
      addMessage(conv.id, 'customer', 'flow', storedText);
      reply = startOtp(conv, conv.pending_phone);
    } else if (otpMode) {
      addMessage(conv.id, 'customer', 'flow', storedText);
      reply = { text: 'Please type the 6-digit code I sent, or say "resend" for a new one.', kind: 'flow' };
    } else {
      const intent = detectIntent(safe);
      const accountish = ['balance', 'transactions', 'transaction_status', 'card_status'].includes(intent);
      const kbHit = !accountish && intent !== 'greeting' ? runTool('search_knowledge', { query: safe }, { conversationId: conv.id, customerId: null }).results : [];
      if (kbHit.length && kbHit[0].score >= 3) {
        addMessage(conv.id, 'customer', 'chat', storedText);
        audit(conv.id, null, 'ai', 'reply', { mode: 'kb_public' });
        reply = { text: kbHit[0].answer, kind: 'chat', topic: 'General enquiry', answered: true };
      } else {
        const useLLM = !accountish && intent !== 'thanks' && llmEnabled();
        addMessage(conv.id, 'customer', useLLM ? 'chat' : 'flow', storedText);
        const smart = useLLM ? await publicAnswer(conv) : null;
        if (smart) {
          reply = { text: smart.text, kind: 'chat', topic: TOPIC_BY_INTENT[intent], answered: !smart.escalated, escalated: smart.escalated };
        } else if (accountish) {
          patch(conv.id, { pending_message: safe, topic: TOPIC_BY_INTENT[intent], state: 'awaiting_phone' });
          reply = { text: "I can help with that. First I need to verify it's you. What mobile number is registered on your account? (e.g. 0976 000 001)", kind: 'flow' };
        } else if (intent === 'greeting' || intent === 'thanks') {
          const GREETINGS = [
            'Hello! I can check your balance, recent transactions and failed or pending transfers, or answer general questions. What would you like help with?',
            "Hi there. What can I help you with today? Try something like 'what is my balance' or 'my transfer failed'.",
            "Hello again. Just tell me what you need, and if it's about your account I'll verify you first.",
          ];
          const n = db.prepare("SELECT COUNT(*) c FROM messages WHERE conversation_id=? AND role='customer'").get(conv.id).c;
          reply = { text: intent === 'thanks' ? "You're welcome! Is there anything else I can help with?" : GREETINGS[(n - 1) % GREETINGS.length], kind: 'flow' };
        } else {
          reply = { text: "I couldn't find that in our general information. If it's about your account, tell me the mobile number registered on it and I'll verify you first. Or say 'speak to a human' and I'll pass you to an agent.", kind: 'flow' };
        }
      }
    }
  }

  // After successful verification, answer the question they originally asked.
  if (reply.justVerified) {
    conv = getConv(conv.id);
    if (conv.pending_message) {
      addMessage(conv.id, 'customer', 'chat', conv.pending_message);
      const follow = await verifiedAnswer(conv, conv.pending_message);
      patch(conv.id, { pending_message: null });
      reply = { ...follow, text: `${reply.text}\n\n${follow.text}`, kind: 'chat' };
    } else {
      reply = { text: `${reply.text} How can I help?`, kind: 'flow' };
    }
  }

  const final = scrubOutput(reply.text);
  const latency = Math.round(performance.now() - t0);
  addMessage(conv.id, 'assistant', reply.kind || 'chat', final, latency);

  const fields = {};
  if (reply.topic) fields.topic = reply.topic;
  conv = getConv(conv.id);
  if (reply.answered && conv.status === 'open') fields.status = 'ai_resolved';
  if (Object.keys(fields).length) patch(conv.id, fields);
  conv = getConv(conv.id);

  return {
    conversationId: conv.id, reply: final, state: conv.state, verified: conv.state === 'verified',
    status: conv.status, language: conv.language, escalated: conv.status === 'escalated',
    ...(sensitive ? { warning: 'For your safety, please never type your PIN, password or full card number into a chat. I removed it.' } : {}),
    ...(reply.demoOtp ? { demoOtp: reply.demoOtp } : {}),
  };
}
